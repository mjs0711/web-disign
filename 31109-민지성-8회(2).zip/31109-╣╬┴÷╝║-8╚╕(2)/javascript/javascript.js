jQuery(document).ready(function(){
    $(".main").mouseover(function(){
       $(".sub").stop().slideDown()
        $(".bgmenu").stop().slideDown()
    })
    $(".main").mouseout(function(){
        $(".sub").stop().slideUp()
        $(".bgmenu").stop().slideUp()
    })

    setInterval(function(){
        $(".imglen").delay(1000)
        $(".imglen").animate({marginLeft:-1200},1000, function(){
            $(".imglen li:first").appendTo(".imglen")
            $(".imglen").css({marginLeft:0})
        })
    })

    $(".no li:first").click(function(){
        $(".popup").show()
        $(".modal").show()
    })
    $(".p3").click(function(){
        $(".popup").hide()
        $(".modal").hide()
    })
})